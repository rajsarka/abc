package com.cg.psa.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.cg.psa.validator.UserValidator;


public class UserTest {
	UserValidator validate = new UserValidator();


	
	@Test
	public void testmethod1() {
		int uid = 123;
		boolean actual = validate.validId(uid);
		boolean expected = true;
		assertEquals(expected,actual);
	}
	@Test
	public void testmethod2() {
		int uid = 123456;
		boolean actual = validate.validId(uid);
		boolean expected = true;
		assertEquals(expected,actual);
	}
}

package com.cg.psa.validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UserValidator {
	
	public boolean validId(int uid) {
		String str=Integer.toString(uid);
		if(str ==null) {
			throw new NullPointerException();
		}
		Pattern pat = Pattern.compile("[0-9]{0,6}");
		Matcher mat = pat.matcher(str);
		if(mat.matches()) 
			return true ;
		else
				return false;
		}

	
}

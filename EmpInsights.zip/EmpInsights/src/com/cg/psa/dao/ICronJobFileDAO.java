package com.cg.psa.dao;

public interface ICronJobFileDAO {
	void checkLastModified(String url);
	void checkNewFileDao(String url);
	void getExcelFiles(String url);
	
}


package com.cg.psa.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;


import com.cg.psa.bean.EmpTesting;

import com.cg.psa.bean.Login;
import com.cg.psa.util.JDBCUtil;
@Repository
@Transactional
public class EmployeeJDBCDAO implements IEmployeeJDBCDAO{

	@PersistenceContext
	EntityManager em = null;
	public EntityManager getEm() {
		return em;
	}
	public void setEm(EntityManager em) {
		this.em = em;
	}

	Login login=new Login();
	EmpTesting et=new EmpTesting();


	public void storeExcelData()
	{}

	public ArrayList<EmpTesting> fetchUsersMgr(String projectLocation,String skill)//according to type of location and skills
	{

		
		String qry="Select emp from EmpTesting emp where emp.projectLocation=:projectLoc and emp.skills like :skills ";
		
		
		TypedQuery<EmpTesting>tq=em.createQuery(qry,EmpTesting.class);
		tq.setParameter("projectLoc", projectLocation);
		tq.setParameter("skills","%"+skill+"%");
		
		ArrayList<EmpTesting> empList=(ArrayList<EmpTesting>) tq.getResultList();
		return empList;
	
	}
	public ArrayList<EmpTesting> fetchAllUsers(String sbuName,String buName,String accountName,String projectLocation,String skill,int pageid,int total)
	{
		
		ArrayList<EmpTesting> empList = new ArrayList<>();

	
			String qry1 = "select empSkills.skill from EmployeeSkills empSkills where empSkills.category=:skills";

			TypedQuery<String> typQry = em.createQuery(qry1, String.class);

			typQry.setParameter("skills", skill);

			List<String> empSkill = typQry.getResultList();
			
			

		


		for (String str1 : empSkill)

		{
			ArrayList<EmpTesting> empList1 = null;
			
			String qry="Select emp from EmpTesting emp where emp.sbuName=:sbuName and emp.buName=:buName and emp.accountName=:accountName and emp.projectLocation=:projectLoc and emp.skills like :skills ";
			
			
			TypedQuery<EmpTesting>tq=em.createQuery(qry,EmpTesting.class);
			tq.setParameter("sbuName", sbuName);
			tq.setParameter("buName", buName);
			tq.setParameter("accountName", accountName);
			tq.setParameter("projectLoc", projectLocation);
			tq.setParameter("skills","%"+str1+"%");
			tq.setFirstResult(pageid);
			tq.setMaxResults(total);
			empList1 = (ArrayList<EmpTesting>) tq.getResultList();
			
			empList.addAll(empList1);
			

		}
		List<EmpTesting> listDistinct = empList.stream().distinct().collect(Collectors.toList());
		return (ArrayList<EmpTesting>) listDistinct;

		
		
	

	}
/*	
public ArrayList<EmpTesting> fetchAllUsers(String sbuName,String buName,String accountName,String projectLocation,String skill,int pageid,int total)
	{
		
		ArrayList<EmpTesting> empList = new ArrayList<>();
		

		TypedQuery<Long> query = em.createQuery(
		  
		  "SELECT COUNT(empSkills) from EmployeeSkills empSkills where empSkills.category=:skills"
		  , Long.class);
		query.setParameter("skills", skill);
		long skillCount = query.getSingleResult();
		 
		
	
			String qry1 = "select empSkills.skill from EmployeeSkills empSkills where empSkills.category=:skills";

			TypedQuery<String> typQry = em.createQuery(qry1, String.class);

			typQry.setParameter("skills", skill);

			List<String> empSkill = typQry.getResultList();
			
			

		


		for (String str1 : empSkill)

		{
			ArrayList<EmpTesting> empList1 = null;
			
			String qry="Select emp from EmpTesting emp where emp.sbuName=:sbuName and emp.buName=:buName and emp.accountName=:accountName and emp.projectLocation=:projectLoc and emp.skills like :skills ";
			
			
			TypedQuery<EmpTesting>tq=em.createQuery(qry,EmpTesting.class);
			tq.setParameter("sbuName", sbuName);
			tq.setParameter("buName", buName);
			tq.setParameter("accountName", accountName);
			tq.setParameter("projectLoc", projectLocation);
			tq.setParameter("skills","%"+str1+"%");
			empList1 = (ArrayList<EmpTesting>) tq.getResultList();
			
			empList.addAll(empList1);
			

		}
		List<EmpTesting> listDistinct = empList.stream().distinct().collect(Collectors.toList());
		return (ArrayList<EmpTesting>) listDistinct;

		//Working Code
		
	/*	String qry="Select emp from EmpTesting emp where emp.sbuName=:sbuName and emp.buName=:buName and emp.accountName=:accountName and emp.projectLocation=:projectLoc and emp.skills like :skills ";
		
		
		TypedQuery<EmpTesting>tq=em.createQuery(qry,EmpTesting.class);
		tq.setParameter("sbuName", sbuName);
		tq.setParameter("buName", buName);
		tq.setParameter("accountName", accountName);
		tq.setParameter("projectLoc", projectLocation);
		tq.setParameter("skills","%"+skill+"%");
		
		ArrayList<EmpTesting> empList=(ArrayList<EmpTesting>) tq.getResultList();
		return empList;

	}*/
	public ArrayList<EmpTesting> fetchAllUsersBU(String accountName )
	{
		String qry="Select emp from EmpTesting emp where emp.buName=:accountName";
		TypedQuery<EmpTesting>tq=em.createQuery(qry,EmpTesting.class);
		tq.setParameter("accountName", accountName);
		ArrayList<EmpTesting> empList=(ArrayList<EmpTesting>) tq.getResultList();
		return empList;

	}



	public void addEmployees()
	{


	}
	public Login getLoginDetails(int id) {
		login= em.find(Login.class, id);
		return login;

	}

	@Override
	public EmpTesting getEmployeeDetailsbyId(int id) {
		et=em.find(EmpTesting.class, id);
		return et;
	}

	@Override
	public ArrayList<String> getAllBU()
	{
		//		String qry="Select distinct emp.buName from EmpTesting  emp where emp.sbuName=:sbu";
		//		 TypedQuery<String> typQry=em.createQuery(qry, String.class);
		//		 typQry.setParameter("sbuName", sbu);
		//		ArrayList<String> empList=(ArrayList<String>)typQry.getResultList();
		//		return empList;
		String qry="Select distinct emp.buName from EmpTesting  emp";
		TypedQuery<String> typQry=em.createQuery(qry, String.class);
		ArrayList<String> empList=(ArrayList<String>)typQry.getResultList();
		return empList;


	}
	@Override
	public ArrayList<String> getAllAccount()
	{
		String qry="Select distinct emp.accountName from EmpTesting  emp";
		TypedQuery<String> typQry=em.createQuery(qry, String.class);
		ArrayList<String> empList=(ArrayList<String>)typQry.getResultList();
		return empList;


	}

	@Override
	public ArrayList<String> getAllSkills()
	{
		String qry="Select distinct ski.category from EmployeeSkills ski";
		TypedQuery<String> typQry=em.createQuery(qry, String.class);
		ArrayList<String> empList=(ArrayList<String>)typQry.getResultList();
		return empList;
		
//		ArrayList<String> empList=(ArrayList<String>) em.createQuery(qry,String.class);
//		return empList;


	}

	@Override
	public ArrayList<String> getAllLocation()
	{
		String qry="Select distinct emp.projectLocation from EmpTesting emp";
		TypedQuery<String> typQry=em.createQuery(qry, String.class);
		ArrayList<String> empList=(ArrayList<String>)typQry.getResultList();
		return empList;
//		ArrayList<String> empList=(ArrayList<String>) em.createQuery(qry,String.class);
//		return empList;


	}

	@Override
	public ArrayList<String> getAllSBU() {

		String qry="Select distinct emp.sbuName from EmpTesting  emp";
		TypedQuery<String> typQry=em.createQuery(qry, String.class);
		ArrayList<String> empList=(ArrayList<String>)typQry.getResultList();
		return empList;

	}
	@Override
	public EmpTesting getEmployeeDetailsByEmail(int empid) {
		//String qry="Select  emp from EmpTesting emp where emp.email=:mail";
		et=em.find(EmpTesting.class, empid);
		//		TypedQuery<EmpTesting> typQry=em.createQuery(qry, EmpTesting.class);
		//		 typQry.setParameter("mail", mail);
		//		 et=typQry.getSingleResult();

		return et;
	}
	@Override
	public Login setPasswordDetails(String password,int empid) {
		login=em.find(Login.class, empid);
		login.setPassword(password);
		em.persist(login);
		return login;
	}
	@Override
	public void validateUser() {
		// TODO Auto-generated method stub

	}
	@Override
	public List<EmpTesting> getEmployeesByPage(int pageid, int total) {
		// TODO Auto-generated method stub
		return null;
	}

	
		
		
	}
	
	


package com.cg.psa.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.psa.bean.EmpTesting;

import com.cg.psa.bean.Login;

public interface IEmployeeJDBCDAO {
	
	void storeExcelData();
	
	void validateUser();//validate user

	public ArrayList<EmpTesting> fetchUsersMgr(String projectLocation,String skill);//according to type of location and skills

	public ArrayList<EmpTesting> fetchAllUsers(String sbuName,String buName,String accountName,String projectLocation,String skills,int pageid,int total);
	public ArrayList<EmpTesting> fetchAllUsersBU(String accountName );

	
	void addEmployees();
	
	public Login getLoginDetails(int id);
	public EmpTesting getEmployeeDetailsbyId(int id);
	
	public ArrayList<String> getAllLocation();
	public ArrayList<String> getAllSkills();
	public ArrayList<String> getAllAccount();
	public ArrayList<String> getAllBU();
	public ArrayList<String> getAllSBU();
	
	public EmpTesting getEmployeeDetailsByEmail(int empid);
	
	public Login setPasswordDetails(String password,int empid);
	
	public List<EmpTesting> getEmployeesByPage(int pageid,int total);
	
}

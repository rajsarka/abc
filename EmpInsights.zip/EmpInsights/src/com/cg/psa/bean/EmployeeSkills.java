package com.cg.psa.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="skills")
public class EmployeeSkills {
	

	@Column(name="category")
	private String category;
	
	@Id
	@Column(name="skill")
	private String skill;
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getSkill() {
		return skill;
	}
	public void setSkill(String skill) {
		this.skill = skill;
	}
	public EmployeeSkills() {
	
	}
	
	

}

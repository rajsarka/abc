/*
 * package com.cg.psa.bean;
 * 
 * import javax.persistence.Column; import javax.persistence.Entity; import
 * javax.persistence.Id; import javax.persistence.Table;
 * 
 * import com.poiji.annotation.ExcelCellName;
 * 
 * @Entity
 * 
 * @Table(name="employeesource") public class EmployeeSource1 {
 * 
 * @ExcelCellName("ID")
 * 
 * @Id
 * 
 * @Column(name="id") private int empId;
 * 
 * @ExcelCellName("Email")
 * 
 * @Column(name="email") private String empEmail;
 * 
 * @ExcelCellName("name")
 * 
 * @Column(name="empName") private String empName;
 * 
 * @ExcelCellName("Primary Skills")
 * 
 * @Column(name="primary_skills") private String empPrimarySkills;
 * 
 * @ExcelCellName("Secondary Skills")
 * 
 * @Column(name="secondary_skills") private String empSecondarySkills;
 * 
 * @ExcelCellName("Domain Skills")
 * 
 * @Column(name="empDomainSkills") private String empSkills;
 * 
 * 
 * @Override public String toString() { return "EmployeeSource1 [empId=" + empId
 * + ", empEmail=" + empEmail + ", empName=" + empName + ", empPrimarySkills=" +
 * empPrimarySkills + ", empSecondarySkills=" + empSecondarySkills +
 * ", empSkills=" + empSkills + ", empCertification=" + empCertification + "]";
 * }
 * 
 * 
 * public EmployeeSource1() { super(); // TODO Auto-generated constructor stub }
 * 
 * 
 * @ExcelCellName("Are you Capgemini Certified Architect")
 * 
 * @Column(name="empCertification") private String empCertification;
 * 
 * 
 * public String getEmpCertification() { return empCertification; }
 * 
 * 
 * public void setEmpCertification(String empCertification) {
 * this.empCertification = empCertification; }
 * 
 * 
 * public EmployeeSource1(int empId, String empEmail, String empName, String
 * empPrimarySkills, String empSecondarySkills, String empSkills, String
 * empCertification) { super(); this.empId = empId; this.empEmail = empEmail;
 * this.empName = empName; this.empPrimarySkills = empPrimarySkills;
 * this.empSecondarySkills = empSecondarySkills; this.empSkills = empSkills;
 * this.empCertification = empCertification; }
 * 
 * 
 * public int getEmpId() { return empId; }
 * 
 * 
 * public void setEmpId(int empId) { this.empId = empId; }
 * 
 * 
 * public String getEmpEmail() { return empEmail; }
 * 
 * 
 * public void setEmpEmail(String empEmail) { this.empEmail = empEmail; }
 * 
 * 
 * public String getEmpName() { return empName; }
 * 
 * 
 * public void setEmpName(String empName) { this.empName = empName; }
 * 
 * 
 * public String getEmpPrimarySkills() { return empPrimarySkills; }
 * 
 * 
 * public void setEmpPrimarySkills(String empPrimarySkills) {
 * this.empPrimarySkills = empPrimarySkills; }
 * 
 * 
 * public String getEmpSecondarySkills() { return empSecondarySkills; }
 * 
 * 
 * public void setEmpSecondarySkills(String empSecondarySkills) {
 * this.empSecondarySkills = empSecondarySkills; }
 * 
 * 
 * public String getEmpSkills() { return empSkills; }
 * 
 * 
 * public void setEmpSkills(String empSkills) { this.empSkills = empSkills; } }
 */
package com.cg.psa.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.psa.bean.EmpTesting;

import com.cg.psa.bean.Login;
import com.cg.psa.dao.EmployeeJDBCDAO;
import com.cg.psa.dao.IEmployeeJDBCDAO;
@Service
public class EmpInsightsService implements IEmpInsightsService {
	@Autowired
	IEmployeeJDBCDAO dao=null;
	public IEmployeeJDBCDAO getDao() {
		return dao;
	}
	public void setDao(IEmployeeJDBCDAO dao) {
		this.dao = dao;
	}
//	public EmpInsightsService() {
//		dao=new EmployeeJDBCDAO(); 
//		}
	@Override
	public void validaterUser() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void fetchUser(String type, String accName) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public ArrayList<EmpTesting> fetchAllUsers(String sbuName,String buName,String accountName,String projectLocation,String skills,int pageid,int total) {
		 return dao.fetchAllUsers(sbuName,buName,accountName,projectLocation,skills,pageid,total);
		
	}
	@Override
	public Login getLoginDetails(int id) {
		
		return dao.getLoginDetails(id);
	}
	@Override
	public EmpTesting getEmployeeDetailsbyId(int id) {
		// TODO Auto-generated method stub
		return dao.getEmployeeDetailsbyId(id);
	}
	@Override
	public ArrayList<EmpTesting> fetchAllUsersBU(String accountName) {
	
		return dao.fetchAllUsersBU(accountName);
	}
	

	@Override
	public ArrayList<String> getAllBU()
	{
		return dao.getAllBU();}
	@Override
	public ArrayList<String> getAllAccount()
	{
		return dao.getAllAccount();
	}
	@Override
	public ArrayList<String> getAllSkills()
	{
		return dao.getAllSkills();}
	@Override
	public ArrayList<String> getAllLocation()
	{
		
		return dao.getAllLocation();}
	
	@Override
	public ArrayList<String> getAllSBU() {
		
		return dao.getAllSBU();
	}
	@Override
	public EmpTesting getEmployeeDetailsbyemial(int empid) {
		return dao.getEmployeeDetailsByEmail(empid);
	}
	@Override
	public Login setPasswordDetails(String password, int empid) {
		
		return dao.setPasswordDetails(password, empid);
	}
	@Override
	public ArrayList<EmpTesting> fetchUsersMgr(String projectLocation, String skill) {
		// TODO Auto-generated method stub
		return dao.fetchUsersMgr(projectLocation, skill);
	}
	@Override
	public List<EmpTesting> getEmployeesByPage(int pageid, int total) {
		
		return dao.getEmployeesByPage(pageid, total);
	}
	
	
	}

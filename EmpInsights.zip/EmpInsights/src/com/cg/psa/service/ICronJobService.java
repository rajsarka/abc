package com.cg.psa.service;

public interface ICronJobService {
	void checkLastModified(String url);
	void checkNewFileDao();
}

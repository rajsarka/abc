package com.cg.psa.service;

public interface IEmpFileParser {

}

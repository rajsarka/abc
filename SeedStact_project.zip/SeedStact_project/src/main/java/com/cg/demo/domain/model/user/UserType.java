package com.cg.demo.domain.model.user;

public enum UserType {
	EMPLOYEE,
    CONTRACTOR 
}

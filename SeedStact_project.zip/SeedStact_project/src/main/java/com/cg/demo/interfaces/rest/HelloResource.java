package com.cg.demo.interfaces.rest;

import javax.inject.Inject;
import javax.transaction.Transactional;
import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.seedstack.business.domain.Repository;
import org.seedstack.business.util.inmemory.InMemory;
import org.seedstack.jpa.Jpa;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Application;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;

import org.slf4j.Logger;
import com.cg.demo.application.MyConfig;
import com.cg.demo.domain.model.person.Person;
import com.cg.demo.domain.model.person.PersonId;
import com.cg.demo.domain.model.person.PersonRepository;
import com.cg.demo.domain.model.user.User;
import com.cg.demo.domain.model.user.UserId;
import com.cg.demo.domain.model.user.UserRepository;
import com.cg.demo.domain.model.user.UserType;
import com.cg.demo.domain.services.GreeterService;
import com.cg.demo.domain.services.UserService;

import io.swagger.annotations.Api;



@Path("hello")
@Api
public class HelloResource {
//	 @Configuration
//	    private MyConfig myConfig;
//	
//	 @Inject
//	    public HelloResource(Application application) {
//		 	System.out.println("Helloresource const is called");
//	        this.application = application;
//	    }
//	 
//	 	//@Inject
//	    private Application application;
//	    
//	    @Inject
//	    private GreeterService greeterService;
	
	  @Inject
	    private UserService userService;
	    
	 /*   @Inject
	    @InMemory
	    private Repository<Person, PersonId> personRepository;
	    */
	    
//	    @Inject
//	    //@InMemory
//	    @Jpa
//	    private PersonRepository personRepository;
	
    @Inject
    //@InMemory
    @Jpa
    private UserRepository userRepository;
	
	    @Logging
		 private Logger logger;
	
	
	    @GET
	    @Transactional
	    @JpaUnit("main")
	    public String hello() {
	        logger.info("The hello() method was called");
	       
	        
	        //return "Hello " + myConfig.getNames().get(0) + "!";
	        
	        
	        
//	        MyConfig myConfig = application.getConfiguration()
//	                .get(MyConfig.class);
//	        return "Hello " + myConfig.getNames().get(1) + "!";
	        
	        
	        
//	        Person person = new Person(new PersonId("rajibsarkar@gmail.com"));
//	        person.changeName("Rajib", "Sarkar");
//	        return greeterService.greet(person);
	      
	        
//getting the data using aggregateId
//stream api code where get=filter
//	        return personRepository.get(new PersonId("bill.evans@some.org"))
//	                .map(greeterService::greet)
//	                .orElseThrow(NotFoundException::new);
	        

//getting the data using name either by fst name or last name
//	        return personRepository.findByName("rajib")
//	                .findFirst()
//	                .map(greeterService::greet)
//	                .orElseThrow(NotFoundException::new);

//	     // getting the data using name either by fst name or last name
//	        return userRepository.findByName("Rajib")
//	                .findFirst()
//	                .orElseThrow(NotFoundException::new);
	      
	       // getting the data using aggregateId
	      //stream api code where get=filter
	      	        return userRepository.get(new UserId(UserType.EMPLOYEE,"1000"))
	      	        		.map(userService::getUser).orElseThrow(NotFoundException::new);	        
	    }
}

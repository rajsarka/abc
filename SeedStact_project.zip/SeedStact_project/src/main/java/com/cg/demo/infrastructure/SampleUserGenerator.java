package com.cg.demo.infrastructure;

import javax.inject.Inject;
import javax.transaction.Transactional;

import org.seedstack.business.domain.Repository;
import org.seedstack.jpa.Jpa;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.LifecycleListener;

import com.cg.demo.domain.model.person.Person;
import com.cg.demo.domain.model.person.PersonId;
import com.cg.demo.domain.model.user.User;
import com.cg.demo.domain.model.user.UserId;
import com.cg.demo.domain.model.user.UserRepository;
import com.cg.demo.domain.model.user.UserType;

public class SampleUserGenerator implements LifecycleListener{
	@Inject
    //@InMemory
	@Jpa
    private Repository<User,  UserId> UserRepository;
 
    @Transactional
    @JpaUnit("main")
    public void started() {
    
         UserRepository.addOrUpdate(create(UserType.EMPLOYEE,"1000", "Bill", "EVANS"));
        UserRepository.addOrUpdate(create(UserType.EMPLOYEE,"1001", "Rajib", "EVANS"));
        UserRepository.addOrUpdate(create(UserType.EMPLOYEE,"1002", "raju", "EVANS"));
        UserRepository.addOrUpdate(create(UserType.CONTRACTOR,"1003", "John", "EVANS"));
    }
 
    private User create(UserType type,String code, String firstName, String lastName) {
    	User user = new User(new UserId(type,code),firstName,lastName);
    	
        return user;
    }
}
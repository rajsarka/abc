package com.cg.demo.domain.services;

import org.seedstack.business.Service;

import com.cg.demo.domain.model.project.Project;
import com.cg.demo.domain.model.user.User;
@Service
public interface ProjectService {
	
	String getUserIdByProjectId(Project proj);
}

package com.cg.demo.interfaces.rest;

import javax.inject.Inject;
import javax.transaction.Transactional;
import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;

import org.apache.commons.lang3.StringUtils;
import org.seedstack.jpa.Jpa;
import org.seedstack.jpa.JpaUnit;

import com.cg.demo.domain.model.user.UserId;
import com.cg.demo.domain.model.user.UserRepository;
import com.cg.demo.domain.model.user.UserType;
import com.cg.demo.domain.services.UserService;

import io.swagger.annotations.Api;

@Path("/users")
@Api
public class UserResource {

	    @Inject
	    private UserService userService;
	  
	    @Inject
	    @Jpa
	    private UserRepository userRepository;
	    

//	    @GET
//	    @Transactional
//	    @JpaUnit("main")
//	    public String getUserDetail(@QueryParam("userType")String type,@QueryParam("code")String code)
//	    {
//	    	if(StringUtils.isEmpty(type)) {
//	    		throw new IllegalArgumentException("user type is empty");
//	    	
//	    	}
//	    	if(StringUtils.isEmpty(code)) {
//	    		throw new IllegalArgumentException("user code is empty");
//	    	
//	    	}
//	    	UserType usertype=UserType.valueOf(type);
//	    	UserId userId=new UserId(usertype,code);
//			return userRepository.get(userId)
//	      	        		.map(userService::getUser).orElseThrow(NotFoundException::new);
//	    }
	    @GET
	    @Transactional
	    @JpaUnit("main")
	    public String getUserDetailByName(@QueryParam("userName")String name)
	    {
	    	if(StringUtils.isEmpty(name)) {
	    		throw new IllegalArgumentException("user Name is empty");
	    	
	    	}
	    	

			return ( userRepository.findByName(name).findFirst()
	      	        		.map(userService::getUser)).orElseThrow(NotFoundException::new);
	    }   
}

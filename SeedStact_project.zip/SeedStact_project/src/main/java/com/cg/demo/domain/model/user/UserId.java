package com.cg.demo.domain.model.user;

import javax.persistence.Embeddable;

import org.seedstack.business.domain.BaseValueObject;
@SuppressWarnings("serial")
@Embeddable
public class UserId extends BaseValueObject {
	
	
	public UserId() {
		
	}

	private  UserType type; 
	    private  String code;
	    
	    public UserId(UserType type, String code) {
	        this.type = type;
	        this.code = code;
	    }
	    
	    public String asString() {
	        return (type == UserType.EMPLOYEE ? "E" : "C") + " & code is " + code;
	    }
}

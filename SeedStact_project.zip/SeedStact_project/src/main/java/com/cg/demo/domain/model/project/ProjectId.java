package com.cg.demo.domain.model.project;



import javax.persistence.Column;
import javax.persistence.Embeddable;

import org.seedstack.business.domain.BaseValueObject;
@SuppressWarnings("serial")
@Embeddable
public class ProjectId extends BaseValueObject {
	
	
	ProjectId() {
		
	}
	
	@Column(name="project_id", nullable=false)
	private  String code;
	    
	    public ProjectId(String code) {
	        this.code = code;
	    }
	    
	    public String getCode() {
	        return this.code;
	    }
}

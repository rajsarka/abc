package com.cg.demo.interfaces.rest;

import javax.inject.Inject;
import javax.transaction.Transactional;
import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;

import org.apache.commons.lang3.StringUtils;
import org.seedstack.business.domain.Repository;
import org.seedstack.jpa.Jpa;
import org.seedstack.jpa.JpaUnit;

import com.cg.demo.domain.model.project.Project;
import com.cg.demo.domain.model.project.ProjectId;
import com.cg.demo.domain.model.project.ProjectRepository;
import com.cg.demo.domain.model.user.UserId;
import com.cg.demo.domain.model.user.UserRepository;
import com.cg.demo.domain.model.user.UserType;
import com.cg.demo.domain.services.ProjectService;
import com.cg.demo.domain.services.UserService;

import io.swagger.annotations.Api;

@Path("/project/{projectId}")
@Api
public class Project1Resource {
	@Inject
    private ProjectService projService;
  
    @Inject
    @Jpa
    private Repository<Project, ProjectId> projectRepository;
    
    
    @GET
    @Transactional
    @JpaUnit("main")
    public String getUserDetail(@PathParam("projectId")String id)
    {
    	if(StringUtils.isEmpty(id)) {
    		throw new IllegalArgumentException("project id  is empty");
    	
    	}
    	
    
    	ProjectId projId=new ProjectId(id);
		return projectRepository.get(projId)
      	        		.map(projService::getUserIdByProjectId).orElseThrow(NotFoundException::new);
    }
}

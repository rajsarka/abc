package com.cg.demo.domain.model.project;


import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;


import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

import com.cg.demo.domain.model.user.UserId;


@Entity
@Table
public class Project extends BaseAggregateRoot<ProjectId> {
	@EmbeddedId
	@Identity
	private  ProjectId project_id;
	
	
    public Project() {
		
	}

	private UserId managerId;
	
	@ElementCollection
	private Set<UserId> members = new HashSet<>();
	
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name="project_id")
	private Map<Integer, Task> tasks = new HashMap<>();
    
    private int maxTaskId = 0;
 
    public Project(ProjectId id) {
        this.project_id = id;
    }
 
    public Project(ProjectId id, UserId managerId) {
		super();
		this.project_id = id;
		this.managerId = managerId;
	}

	public void addMember(UserId memberId) {
        members.add(memberId);
    }
 
    public UserId getManager() {
        return managerId;
    }
 
    public Project(ProjectId id, UserId managerId, Set<UserId> members, Map<Integer, Task> tasks) {
		super();
		this.project_id = id;
		this.managerId = managerId;
		this.members = members;
		this.tasks = tasks;
	}

	public void changeManager(UserId managerId) {
        // We ensure that the manager is always a member of the project
        if (!members.contains(managerId)) {
            members.add(managerId);
        }
        this.managerId = managerId;
    }
 
    public Task createTask(String title) {
        // This factory method generate an identity for the new task
        Task task = new Task(++maxTaskId, title);
        tasks.put(task.getId(), task);
        return task;
    }
 
    public Optional<ProjectCompleted> completeTask(int taskId) {
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Unable to find task number " + taskId);
        }
        // The package-private method is not accessible outside the aggregate
        task.markCompleted();
        if (tasks.values().stream().allMatch(Task::isCompleted)) {
            return Optional.of(new ProjectCompleted(project_id, tasks.size()));
        } else {
            return Optional.empty();
        }
    }
}

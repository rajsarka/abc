package com.cg.demo.domain.model.project;




import javax.persistence.Entity;
import javax.persistence.Id;

import org.seedstack.business.domain.BaseEntity;
@Entity
public class Task extends BaseEntity<Integer> {
	@Id
	private  Integer id;
    private  String title;
    private boolean completed;
    Task() {
    	
    }
    public Task(int id, String title) {
        this.id = id;
        this.title = title;
    }
 
    public boolean isCompleted() {
        return this.completed;
    }
 
    void markCompleted() {
        this.completed = true;
    }
}

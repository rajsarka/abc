package com.cg.demo.domain.services;

import com.cg.demo.domain.model.person.Person;
import com.cg.demo.domain.model.user.User;

public class UserServiceImpl implements UserService{

	@Override
	public String getUser(User user) {

		
	        return String.format(
	                "This is  %s %s & code is %s",
	                user.getFirstName(),user.getLastName(),user.getId().toString()
	                
	        );
	    }
	}



package com.cg.demo.domain.model.person;

import javax.persistence.Embeddable;

import org.seedstack.business.domain.BaseValueObject;
@SuppressWarnings("serial")
@Embeddable
public class PersonId extends BaseValueObject {

	@SuppressWarnings("unused")
	private PersonId() {
		
		
	}
	private  String email;
	 
    public PersonId(String email) {
        this.email = email;
    }
 
    public String getEmail() {
        return email;
    }

	
    
    
}
	


package com.cg.demo.infrastructure;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import javax.inject.Inject;
import javax.transaction.Transactional;
import org.seedstack.business.domain.Repository;
import org.seedstack.jpa.Jpa;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.LifecycleListener;
import com.cg.demo.domain.model.person.Person;
import com.cg.demo.domain.model.person.PersonId;
import com.cg.demo.domain.model.project.Project;
import com.cg.demo.domain.model.project.ProjectId;
import com.cg.demo.domain.model.project.ProjectRepository;
import com.cg.demo.domain.model.project.Task;
import com.cg.demo.domain.model.user.User;
import com.cg.demo.domain.model.user.UserId;
import com.cg.demo.domain.model.user.UserRepository;
import com.cg.demo.domain.model.user.UserType;



	public class SampleProjectGenerator implements LifecycleListener{
		@Inject
		@Jpa
	    private Repository<Project, ProjectId> projectRepository;
	 

	   
		@Override
	    @Transactional
	    @JpaUnit("main")
	    public void started() {
	        projectRepository.addOrUpdate(createProject(new ProjectId("2000")));
	        projectRepository.addOrUpdate(createProject(new ProjectId("2001")));
	        projectRepository.addOrUpdate(createProject(new ProjectId("2002")));
	        projectRepository.addOrUpdate(createProject(new ProjectId("2003")));
		}
	    private Project createProject(ProjectId id) {
	    	
	    	Project proj = new Project(id);
	
//	    	UserId memberId = new UserId(UserType.EMPLOYEE, "100");
//			proj.addMember(memberId);
//			proj.changeManager(memberId);

			UserId memberId1 =new UserId(UserType.CONTRACTOR, "200");
			proj.addMember(memberId1);
			proj.changeManager(memberId1);
	
//			UserId memberId2 =new UserId(UserType.EMPLOYEE, "300");
//			proj.addMember(memberId2);
//			proj.changeManager(memberId2);
	 	
			
			//proj.createTask("Alpha");
	    	//proj.createTask("Beta");
	    	//proj.completeTask(1);
	        return proj;
	    }
	}


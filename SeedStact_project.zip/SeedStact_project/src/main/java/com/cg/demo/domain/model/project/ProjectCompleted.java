package com.cg.demo.domain.model.project;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

import org.seedstack.business.domain.BaseDomainEvent;

@SuppressWarnings("serial")
@Entity
public class ProjectCompleted extends BaseDomainEvent {
	@EmbeddedId
	private  ProjectId projectId;
    private  int taskCount;
 
    public ProjectCompleted() {
		
	}

	public ProjectCompleted(ProjectId projectId, int taskCount) {
        this.projectId = projectId;
        this.taskCount = taskCount;
    }
 
    public ProjectId getProjectId() {
        return projectId;
    }
 
    public int getTaskCount() {
        return taskCount;
    }

}

package com.cg.demo.domain.model.person;

import java.util.stream.Stream;

import org.seedstack.business.domain.Repository;

public interface PersonRepository extends Repository<Person, PersonId>{
	
	default Stream<Person> findByName(String name) {
       
		return get(getSpecificationBuilder().of(Person.class)
                .property("firstName").matching(name).ignoringCase()
                .or()
                .property("lastName").matching(name).ignoringCase()
                .build()
        );
    }
}


package com.cg.demo.domain.services;

import com.cg.demo.domain.model.project.Project;
import com.cg.demo.domain.model.user.User;

public class ProjectServiceImpl implements ProjectService{

	@Override
	public String getUserIdByProjectId(Project proj) {
		

			
	        return String.format(
	                "This is  %s whose manager is of type %s",
	                proj.getId().toString(),proj.getManager().asString()
	                
	        );
	    }
	

	}



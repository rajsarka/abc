package com.cg.demo.domain.services;

import org.seedstack.business.Service;

import com.cg.demo.domain.model.user.User;
@Service
public interface UserService {
String getUser(User user);
}

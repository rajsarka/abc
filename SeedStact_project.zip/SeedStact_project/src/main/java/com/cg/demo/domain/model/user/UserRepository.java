package com.cg.demo.domain.model.user;

import java.util.stream.Stream;

import org.seedstack.business.domain.Repository;

import com.cg.demo.domain.model.person.Person;


public interface UserRepository extends Repository<User, UserId>{
	default Stream<User> findByName(String name) {
	       
		return get(getSpecificationBuilder().of(User.class)
                .property("firstName").matching(name).ignoringCase()
                .or()
                .property("lastName").matching(name).ignoringCase()
                .build()
        );
    }
}



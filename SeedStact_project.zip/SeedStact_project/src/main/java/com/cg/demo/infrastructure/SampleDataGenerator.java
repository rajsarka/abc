package com.cg.demo.infrastructure;

import javax.inject.Inject;
import javax.transaction.Transactional;

import org.seedstack.business.domain.Repository;
import org.seedstack.business.util.inmemory.InMemory;
import org.seedstack.jpa.Jpa;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.LifecycleListener;


import com.cg.demo.domain.model.person.Person;
import com.cg.demo.domain.model.person.PersonId;

public class SampleDataGenerator implements LifecycleListener{
	@Inject
    //@InMemory
	@Jpa
    private Repository<Person, PersonId> personRepository;
 
    @Override
    @Transactional
    @JpaUnit("main")
    public void started() {
        personRepository.addOrUpdate(create("bill.evans@some.org", "Bill", "EVANS"));
        personRepository.addOrUpdate(create("rajib.sarkar@some.org", "Rajib", "Sarkar"));
        personRepository.addOrUpdate(create("miles.davis@some.org", "Miles", "DAVIS"));
    }
 
    private Person create(String email, String firstName, String lastName) {
        Person person = new Person(new PersonId(email));
        person.changeName(firstName, lastName);
        return person;
    }
}
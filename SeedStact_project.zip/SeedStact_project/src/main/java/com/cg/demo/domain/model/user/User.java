package com.cg.demo.domain.model.user;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.seedstack.business.domain.BaseAggregateRoot;
@Entity
@Table
public class User extends BaseAggregateRoot<UserId> {
	@EmbeddedId
	private  UserId id;
	
	public User() {
		
	}
    private  String firstName;
    private  String lastName;
    
    public User(UserId id, String firstName, String lastName) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
    }
    
   

	



	public String getFirstName() {
        return firstName;
    }
    
    public String getLastName() {
        return lastName;
    }

public UserId getId() {
		return id;
	}




    
}

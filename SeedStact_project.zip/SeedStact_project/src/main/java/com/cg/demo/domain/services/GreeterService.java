package com.cg.demo.domain.services;

import org.seedstack.business.Service;

import com.cg.demo.domain.model.person.Person;

@Service
public interface GreeterService {
	String greet(Person person);
}

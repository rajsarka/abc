package com.cg.demo.domain.model.project;



import java.util.Optional;
import java.util.stream.Stream;

import org.seedstack.business.domain.Repository;

import com.cg.demo.domain.model.user.UserId;



public interface ProjectRepository extends Repository<Project, ProjectId>{
	default Stream<Project> findById(String id) {
	       
		return get(getSpecificationBuilder().of(Project.class)
                .property("firstName").matching(id).ignoringCase()
                .or()
                .property("lastName").matching(id).ignoringCase()
                .build()
        );
    }

}
package com.cg.demo.domain.services;

import com.cg.demo.domain.model.person.Person;

public class DefaultGreeterService implements GreeterService{

	@Override
    public String greet(Person person) {
        return String.format(
                "Hello %s %s!",
                person.getFirstName(),
                person.getLastName()
        );
    }
}
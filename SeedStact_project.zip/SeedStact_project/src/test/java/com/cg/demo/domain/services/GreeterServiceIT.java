package com.cg.demo.domain.services;

import static org.assertj.core.api.Assertions.assertThat;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.testing.junit4.SeedITRunner;

import com.cg.demo.domain.model.person.Person;
import com.cg.demo.domain.model.person.PersonId;

@RunWith(SeedITRunner.class)
	public class GreeterServiceIT {
	    @Inject
	    private GreeterService greeterService;
	 
	    @Test
	    public void testGreeting() throws Exception {
	        Person person = new Person(new PersonId("test@some.org"));
	        person.changeName("testFirstName", "testLastName");
	        assertThat(greeterService.greet(person)).isEqualTo("Hello testFirstName testLastName!");
	        //Assert.assertTrue(greeterService.greet(person)).isEqualTo("Hello testFirstName testLastName!");

	    }
	}